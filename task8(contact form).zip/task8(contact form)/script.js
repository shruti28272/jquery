$(document).ready(function() {
    $('#contactForm').submit(function(event) {
        event.preventDefault(); // Prevent the form from submitting via the browser

        var isValid = true;

        // Basic validation
        $('#contactForm input, #contactForm textarea').each(function() {
            if ($(this).val() === '') {
                isValid = false;
                $(this).css('border-color', 'red');
            } else {
                $(this).css('border-color', '#ccc');
            }
        });

        if (isValid) {
            // If form is valid, perform an AJAX request (simulated here)
            window.alert('Form submitted successfully!');

            // Clear the form
            $('#contactForm')[0].reset();
        } else {
            alert('Please fill out all fields.');
        }
    });
});

$(document).ready(function() {
   $("#registrationForm").validate({
       rules: {
           username: {
               required: true,
               minlength: 3
           },
           email: {
               required: true,
               email: true
           },
           contact: {
            required: true,
            contact: true
        },
           password: {
               required: true,
               minlength: 5
           },
           confirm_password: {
               required: true,
               equalTo: "#password"
           }
       },
       messages: {
           username: {
               required: "Please enter your username",
               minlength: "Your username must consist of at least 3 characters"
           },
           email: "Please enter a valid email address",
           password: {
               required: "Please provide a password",
               minlength: "Your password must be at least 5 characters long"
           },

           contact: "Your contact no must be at least 10 digit long",
           password: {
               required: "Please provide a password",
               minlength: "Your contact no must be at least 10 digit long"
           },

           confirm_password: {
               required: "Please confirm your password",
               equalTo: "Password does not match"
           }
       },
       submitHandler: function(form) {
           form.submit();
       }
   });
});
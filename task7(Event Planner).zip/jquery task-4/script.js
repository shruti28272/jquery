document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('eventForm');
    const eventList = document.getElementById('eventList');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const title = document.getElementById('title').value;
        const date = document.getElementById('date').value;

        if (title && date) {
            addEvent(title, date);
            form.reset();
        }
    });

    function addEvent(title, date) {
        const li = document.createElement('li');
        li.textContent = `${title} - ${date}`;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function() {
            eventList.removeChild(li);
        });

        li.appendChild(deleteButton);
        eventList.appendChild(li);
    }
});

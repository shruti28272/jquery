
$(document).ready(function() {
    // Add a habit to the list
    $('#add-habit-form').on('submit', function(event) {
        event.preventDefault();

        var habitName = $('#habit-name').val().trim();

        if (habitName) {
            var habitItem = `
                <li class="habit-item">
                    <span>${habitName}</span>
            
                    <button class="delete-habit">Delete</button>
                </li>
            `;

            $('#habit-list').append(habitItem);
            $('#habit-name').val(''); // Clear input field
        }
    });

    // Delete a habit from the list
    $('#habit-list').on('click', '.delete-habit', function() {
        $(this).parent().remove();
    });
});

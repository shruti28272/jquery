$(document).ready(function() {
    $('.toggle-details').on('click', function() {
        var $details = $(this).siblings('.details');
        if ($details.is(':visible')) {
            $details.slideUp();
            $(this).text('View Details');
        } else {
            $('.details').slideUp(); // Hide all other details
            $('.toggle-details').text('View Details'); // Reset text for all buttons
            $details.slideDown();
            $(this).text('Hide Details');
        }
    });
});
